/*
 Navicat Premium Data Transfer

 Source Server         : Test
 Source Server Type    : MySQL
 Source Server Version : 50730
 Source Host           : localhost:3306
 Source Schema         : hotel

 Target Server Type    : MySQL
 Target Server Version : 50730
 File Encoding         : 65001

 Date: 07/12/2020 10:35:33
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for anyname
-- ----------------------------
DROP TABLE IF EXISTS `anyname`;
CREATE TABLE `anyname`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(12) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `phone` varchar(14) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `gtime` date NULL DEFAULT NULL,
  `text` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 11 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of anyname
-- ----------------------------
INSERT INTO `anyname` VALUES (1, '赵志成', '13792344723', NULL, '李长昊最帅！！！');
INSERT INTO `anyname` VALUES (3, '赵志成', '13792344723', '2020-12-02', '哈哈哈哈哈哈哈哈好');
INSERT INTO `anyname` VALUES (4, '赵志成', '13792344723', '2020-12-02', '哈哈哈哈哈哈哈哈好');
INSERT INTO `anyname` VALUES (5, '赵志成', '13792344723', '2020-12-02', '李长昊最帅');
INSERT INTO `anyname` VALUES (6, '赵亚平', '15689016712', '2020-12-02', '李长昊最帅！！');
INSERT INTO `anyname` VALUES (7, NULL, NULL, '2020-12-03', NULL);
INSERT INTO `anyname` VALUES (8, '李长昊', '13792344723', '2020-12-03', '这里的菜真的好吃');
INSERT INTO `anyname` VALUES (9, NULL, NULL, '2020-12-03', NULL);
INSERT INTO `anyname` VALUES (10, '李长昊', '13792344723', '2020-12-03', '这里的土豆真好吃');

-- ----------------------------
-- Table structure for cuisine
-- ----------------------------
DROP TABLE IF EXISTS `cuisine`;
CREATE TABLE `cuisine`  (
  `cid` int(11) NOT NULL AUTO_INCREMENT,
  `cname` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `count` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`cid`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 44 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of cuisine
-- ----------------------------
INSERT INTO `cuisine` VALUES (35, '鲁', 3);
INSERT INTO `cuisine` VALUES (36, '苏', 2);
INSERT INTO `cuisine` VALUES (41, '湘', 1);
INSERT INTO `cuisine` VALUES (43, '闽', 0);

-- ----------------------------
-- Table structure for customer
-- ----------------------------
DROP TABLE IF EXISTS `customer`;
CREATE TABLE `customer`  (
  `username` varchar(12) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `password` varchar(16) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`username`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of customer
-- ----------------------------
INSERT INTO `customer` VALUES ('lch', '123');
INSERT INTO `customer` VALUES ('lihua', '123');
INSERT INTO `customer` VALUES ('张志成', '111');

-- ----------------------------
-- Table structure for dtable
-- ----------------------------
DROP TABLE IF EXISTS `dtable`;
CREATE TABLE `dtable`  (
  `tid` int(11) NOT NULL AUTO_INCREMENT,
  `tposition` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `tusing` int(10) NULL DEFAULT NULL,
  PRIMARY KEY (`tid`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 16 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of dtable
-- ----------------------------
INSERT INTO `dtable` VALUES (1, '1-101', 0);
INSERT INTO `dtable` VALUES (2, '1-101', 0);
INSERT INTO `dtable` VALUES (3, '1-102', 0);
INSERT INTO `dtable` VALUES (4, '1-103', 0);
INSERT INTO `dtable` VALUES (5, '2-204', 0);
INSERT INTO `dtable` VALUES (6, '2-201', 0);
INSERT INTO `dtable` VALUES (7, '3-301', 0);
INSERT INTO `dtable` VALUES (8, '3-301', 0);
INSERT INTO `dtable` VALUES (9, '2-204', 0);
INSERT INTO `dtable` VALUES (10, '1-101', 0);
INSERT INTO `dtable` VALUES (11, '1-101', 0);
INSERT INTO `dtable` VALUES (12, '1-101', 0);
INSERT INTO `dtable` VALUES (13, '4-404', 0);
INSERT INTO `dtable` VALUES (14, '4-403', 0);
INSERT INTO `dtable` VALUES (15, '2-208', 0);

-- ----------------------------
-- Table structure for menu
-- ----------------------------
DROP TABLE IF EXISTS `menu`;
CREATE TABLE `menu`  (
  `mid` int(11) NOT NULL AUTO_INCREMENT,
  `mname` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `cuisine` int(11) NULL DEFAULT NULL,
  `price` double(10, 2) NULL DEFAULT NULL,
  `state` int(11) NULL DEFAULT NULL,
  `addtime` date NULL DEFAULT NULL,
  `heat` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`mid`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 48 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of menu
-- ----------------------------
INSERT INTO `menu` VALUES (36, '狮子头', 36, 100.00, 0, '2020-11-12', 38);
INSERT INTO `menu` VALUES (40, '西红柿', 35, 10.00, 0, '2020-11-23', 8);
INSERT INTO `menu` VALUES (41, '西红柿炒鸡蛋', 35, 70.00, 0, '2020-11-23', 2);
INSERT INTO `menu` VALUES (43, '鱼', 35, 30.56, 1, '2020-11-29', 19);
INSERT INTO `menu` VALUES (44, '西红柿', 36, 10.00, 0, '2020-12-01', 0);
INSERT INTO `menu` VALUES (46, '宫保鸡丁', 41, 50.00, 0, '2020-12-04', 0);

-- ----------------------------
-- Table structure for merchant
-- ----------------------------
DROP TABLE IF EXISTS `merchant`;
CREATE TABLE `merchant`  (
  `username` varchar(12) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `password` varchar(16) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`username`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of merchant
-- ----------------------------
INSERT INTO `merchant` VALUES ('111', '1');
INSERT INTO `merchant` VALUES ('cs01', '123456');
INSERT INTO `merchant` VALUES ('lch', '1');
INSERT INTO `merchant` VALUES ('lch0', '123');
INSERT INTO `merchant` VALUES ('lch000', '111');
INSERT INTO `merchant` VALUES ('lch0010', '456');
INSERT INTO `merchant` VALUES ('lch01', '111');
INSERT INTO `merchant` VALUES ('lch02', '22');
INSERT INTO `merchant` VALUES ('lch03', '1');
INSERT INTO `merchant` VALUES ('lch100', '1');
INSERT INTO `merchant` VALUES ('lgw', '147258369');
INSERT INTO `merchant` VALUES ('lihua', '456');
INSERT INTO `merchant` VALUES ('ls', '789');
INSERT INTO `merchant` VALUES ('ls1001', '1');
INSERT INTO `merchant` VALUES ('zyp', '456123');
INSERT INTO `merchant` VALUES ('zzc', '123456');
INSERT INTO `merchant` VALUES ('zzy', '1111');
INSERT INTO `merchant` VALUES ('赵亚平', '1111');

-- ----------------------------
-- Table structure for ordertable
-- ----------------------------
DROP TABLE IF EXISTS `ordertable`;
CREATE TABLE `ordertable`  (
  `oid` int(11) NOT NULL AUTO_INCREMENT,
  `vid` int(11) NOT NULL,
  `tid` int(11) NOT NULL,
  `totalprice` double(10, 2) NULL DEFAULT NULL,
  `paymentstate` int(11) NOT NULL,
  `gtime` date NULL DEFAULT NULL,
  PRIMARY KEY (`oid`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 27 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of ordertable
-- ----------------------------
INSERT INTO `ordertable` VALUES (18, 8, 2, 220.50, 1, '2020-11-29');
INSERT INTO `ordertable` VALUES (19, 8, 1, 100.00, 1, '2020-11-29');
INSERT INTO `ordertable` VALUES (20, 8, 3, 430.56, 1, '2020-11-29');
INSERT INTO `ordertable` VALUES (21, 11, 3, 122.24, 1, '2020-12-01');
INSERT INTO `ordertable` VALUES (22, 11, 1, 151.50, 1, '2020-12-01');
INSERT INTO `ordertable` VALUES (23, 11, 4, 70.00, 1, '2020-11-19');
INSERT INTO `ordertable` VALUES (24, 11, 6, 427.84, 1, '2020-12-03');
INSERT INTO `ordertable` VALUES (25, 13, 2, 460.50, 1, '2020-12-03');
INSERT INTO `ordertable` VALUES (26, 11, 2, 300.00, 1, '2020-12-04');

-- ----------------------------
-- Table structure for vip
-- ----------------------------
DROP TABLE IF EXISTS `vip`;
CREATE TABLE `vip`  (
  `vid` int(11) NOT NULL AUTO_INCREMENT,
  `vname` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `vsex` varchar(2) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `vphone` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `opentime` date NULL DEFAULT NULL,
  `usecount` int(11) NULL DEFAULT NULL,
  `balance` double(10, 0) NULL DEFAULT NULL,
  `version` int(255) NOT NULL DEFAULT 1,
  PRIMARY KEY (`vid`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 18 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of vip
-- ----------------------------
INSERT INTO `vip` VALUES (8, '李长昊', '男', '13792344723', '2020-11-29', 3, 0, 0);
INSERT INTO `vip` VALUES (9, '赵亚平', '女', '13792344723', '2020-11-29', 0, 100, 0);
INSERT INTO `vip` VALUES (10, 'lch', '女', '13792344723', '2020-11-30', 0, 300, 0);
INSERT INTO `vip` VALUES (11, '宋世豪', '男', '13792344722', '2020-11-30', 5, 0, 1);
INSERT INTO `vip` VALUES (12, '李树', '男', '15550342627', '2020-11-30', 0, 300, 1);
INSERT INTO `vip` VALUES (13, '赵亚平', '男', '15689001762', '2020-12-01', 1, 0, 0);
INSERT INTO `vip` VALUES (14, '李长昊', '女', '13792344723', '2020-12-02', 0, 100, 0);
INSERT INTO `vip` VALUES (15, '张志成', '男', '13792344725', '2020-12-03', 0, 200, 1);
INSERT INTO `vip` VALUES (16, '李帅帅', '男', '13792344728', '2020-12-03', 0, 2000, 1);
INSERT INTO `vip` VALUES (17, '李国文', '男', '19862516360', '2020-12-03', 0, 1000, 1);

-- ----------------------------
-- View structure for char_time
-- ----------------------------
DROP VIEW IF EXISTS `char_time`;
CREATE ALGORITHM = UNDEFINED SQL SECURITY DEFINER VIEW `char_time` AS select `ordertable`.`gtime` AS `gtime`,sum(`ordertable`.`totalprice`) AS `stotalprice` from `ordertable` where (`ordertable`.`paymentstate` = 1) group by `ordertable`.`gtime`;

-- ----------------------------
-- View structure for ve_menu
-- ----------------------------
DROP VIEW IF EXISTS `ve_menu`;
CREATE ALGORITHM = UNDEFINED SQL SECURITY DEFINER VIEW `ve_menu` AS select `menu`.`mid` AS `mid`,`menu`.`mname` AS `mname`,`cuisine`.`cname` AS `cname`,`menu`.`price` AS `price`,`menu`.`state` AS `state`,`menu`.`addtime` AS `addtime`,`menu`.`heat` AS `heat` from (`menu` join `cuisine`) where (`menu`.`cuisine` = `cuisine`.`cid`);

-- ----------------------------
-- View structure for ve_order
-- ----------------------------
DROP VIEW IF EXISTS `ve_order`;
CREATE ALGORITHM = UNDEFINED SQL SECURITY DEFINER VIEW `ve_order` AS select `ordertable`.`oid` AS `oid`,`ordertable`.`gtime` AS `gtime`,`ordertable`.`paymentstate` AS `paymentstate`,`ordertable`.`totalprice` AS `totalprice`,`ordertable`.`tid` AS `tid`,`vip`.`vname` AS `vname` from (`vip` join `ordertable`) where (`vip`.`vid` = `ordertable`.`vid`);

SET FOREIGN_KEY_CHECKS = 1;
