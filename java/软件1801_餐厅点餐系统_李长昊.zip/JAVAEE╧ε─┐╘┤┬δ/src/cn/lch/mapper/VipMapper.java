package cn.lch.mapper;

import java.util.List;

import cn.lch.beans.Vip;

public interface VipMapper {
	public List<Vip> findVip() ; 
	
	public void addVip(Vip vip) ;
	
	public Vip findByNameAndPhone(Vip v) ; 
	
	public void adduseCount(Vip v) ; 
	
	public void deleteVip(Integer id)  ; 
	
	public Vip findByVid(Integer id) ; 
	
	public void setBalance(Vip v) ;
	
	public Vip findByVidN(Integer id) ; 
	
	public void setBa(Integer id) ; 
	
}
