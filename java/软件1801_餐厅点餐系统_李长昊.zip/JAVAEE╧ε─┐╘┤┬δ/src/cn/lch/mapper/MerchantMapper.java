package cn.lch.mapper;

import java.util.List;

import cn.lch.beans.Customer;
import cn.lch.beans.Merchant;



public interface MerchantMapper {
	
	public Merchant findAllM(String username);
	
	public void addMerchant(Merchant muser) ; 

}
