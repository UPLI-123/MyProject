package cn.lch.mapper;

import java.util.List;

import cn.lch.beans.Customer;

public interface CustomerMapper {
	
	
	public Customer findAllC(String username);
	
	public void addCustomer(Customer cuser) ; 
	
	

}
