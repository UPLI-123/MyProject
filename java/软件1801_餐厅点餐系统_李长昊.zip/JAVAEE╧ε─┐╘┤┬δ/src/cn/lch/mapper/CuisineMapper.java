package cn.lch.mapper;

import java.util.List;

import cn.lch.beans.Cuisine;

public interface CuisineMapper {
	
	
	public List<Cuisine> findAllCuisine()  ; 
	public void addCuisine(Cuisine c) ; 
	public void deleteCuisineByid(Integer id) ; 
	public void updateCuisineCount(Integer id) ; 
	public void subCuisineCount(Integer id) ;

}
