package cn.lch.mapper;

import java.util.List;

import cn.lch.beans.Menu;
import cn.lch.beans.MenuVo;

public interface MenuMapper {
	
	public List<Menu> findAllMenu() ; 
	
	public Menu findByIdMenu(int id) ; 
	
	public void deleteMenuById(int id) ; 
	 
	public Integer addMenu(Menu m) ; 
	 
	public void deleteByCid(Integer cuisine) ; 
	
	public List<MenuVo> findByAllVmenu();
	
	public void updateMenuName(Menu m) ; 
	
	public void updateState(Menu m) ;
	
	public MenuVo findByIdMenuVo(int id) ;
	
	public List<MenuVo> findByAllVmenuS();
	
	public void addHeat(Menu m)  ; 
	
}
