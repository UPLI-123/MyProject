package cn.lch.mapper;

import java.util.List;

import cn.lch.beans.Dtable;

public interface DtableMapper {
	
	public List<Dtable> findAllTable() ; 
	
	public void addTable(Dtable table) ; 
	
	public void updateTableState(Integer id) ; 
	
	public Dtable findByTid(Integer tid) ; 
	
	
	public List<Dtable> findByActionTable() ; 
	
	public void updateUsing(Integer id );

}
