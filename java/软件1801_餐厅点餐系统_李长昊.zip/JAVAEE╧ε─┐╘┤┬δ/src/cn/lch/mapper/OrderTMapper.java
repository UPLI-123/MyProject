package cn.lch.mapper;

import java.util.Date;
import java.util.List;

import cn.lch.beans.CharMode;
import cn.lch.beans.Ordertable;
import cn.lch.beans.OrdertableVo;

public interface OrderTMapper {
	
	public List<Ordertable> findOrder();
	
	public void addOrder(Ordertable o) ;
	
	public List<Ordertable> findOrderAll(OrdertableVo v); 
	
	public Ordertable findByOid(int id) ; 
	
	public void updateOrder(int id)  ;
	
	public List<CharMode> findTotalPrice() ; 
	
	public CharMode findTotalPriceByOne(String time) ; 

}
