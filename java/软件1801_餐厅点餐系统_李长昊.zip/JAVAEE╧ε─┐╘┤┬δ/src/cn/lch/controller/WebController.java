package cn.lch.controller;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.tools.ant.taskdefs.Move;
import org.dom4j.io.XMLResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.View;

import com.fasterxml.jackson.annotation.JsonCreator.Mode;
import com.sun.org.apache.xpath.internal.operations.Mod;

import cn.lch.beans.Anyname;
import cn.lch.beans.CharMode;
import cn.lch.beans.Cuisine;
import cn.lch.beans.Customer;
import cn.lch.beans.Dtable;
import cn.lch.beans.ImageVerificationCode;
import cn.lch.beans.JsonResult;
import cn.lch.beans.Menu;
import cn.lch.beans.MenuVo;
import cn.lch.beans.Merchant;
import cn.lch.beans.Ordertable;
import cn.lch.beans.OrdertableVo;
import cn.lch.beans.Vip;
import cn.lch.service.OrderService;
import cn.lch.service.SuggestionService;
import cn.lch.service.VipService;
import cn.lch.service.WebService;
import javassist.tools.web.Webserver;
import tools.ArraysReserve;
import tools.TimeConvert;
@Controller
public class WebController {
	
	//������¼�˿͵㵥ʱ��Ĳ�
	private List<MenuVo> mlist  = new ArrayList<MenuVo>(); 
	
	@Autowired
	WebService service ; 
	@Autowired
	OrderService oservice; 
	@Autowired
	VipService vservice; 
	@Autowired
	SuggestionService sservice ; 
	
	@RequestMapping("/login.action")
	public String login() {
		return "/WEB-INF/jsp/login.jsp" ; 
	}
	@RequestMapping("/index01.action")
	public String index01() {
		return "/WEB-INF/jsp/index01.jsp" ; 
	}
	@RequestMapping("/index02.action")
	public String index02() {
		return "/WEB-INF/jsp/index02.jsp" ; 
	}
	
	@RequestMapping("/register.action")
	public String register() {
		return "/WEB-INF/jsp/register.jsp" ; 
	}
	
	@RequestMapping("/index.action")
	public String index(HttpServletRequest req) {
		String username = req.getParameter("username") ; 
		String password = req.getParameter("password") ; 
		HttpSession session = req.getSession() ; 
		Merchant muser = service.findAllM(username);
		System.out.println(muser);
		if (muser!=null && muser.getPassword().equals(password)) {
				session.setAttribute("muser", muser);
				return "/WEB-INF/jsp/index02.jsp" ; 
			}
		return "/login.action" ; 
	}
	
	@RequestMapping("/addUser.action")
	public String addUser(HttpServletRequest req) {
		
		String type = req.getParameter("type") ;
		String username = req.getParameter("username") ; 
		String password = req.getParameter("password") ; 
		Merchant muser =  new Merchant(0,username,password) ; 
		service.addMerchant(muser);
		System.out.println(muser);
	
		return "/login.action" ; 
	}
	
	
	@RequestMapping("/hello.action")
	public String hello() {
		return "/WEB-INF/jsp/Hello.jsp" ; 
	}
	//�˵��б�
	@RequestMapping("/menulist.action")
	public ModelAndView menulist() {
		ModelAndView mv = new ModelAndView();
		List<MenuVo> menu = service.findByAllVmenu();  
		System.out.println(menu);
		mv.addObject("menu", menu) ;
		mv.setViewName("/WEB-INF/jsp/menulist.jsp");
		return mv ; 
	}
	//��ת�����Ӳ˵��б�
	@RequestMapping("/addmenu.action")
	public ModelAndView addmenu() {
		ModelAndView mv = new ModelAndView() ; 
		List<Cuisine> list = service.findAllCuisine() ;
		mv.addObject("mlist",list)  ;
		mv.setViewName("/WEB-INF/jsp/addmenu.jsp");
		return mv ; 
	}
	//��ϵ�б�
	@RequestMapping("/cuisine.action")
	public ModelAndView cuisine() {
		ModelAndView mv = new ModelAndView();
		List<Cuisine> cuisine = service.findAllCuisine() ; 
		System.out.println(cuisine);
		mv.addObject("cuisine", cuisine) ;
		mv.setViewName("/WEB-INF/jsp/cuisine.jsp");
		return mv ; 
	}
	//��ת���Ӳ�ϵ
	@RequestMapping("/addCuisine.action")
	public String addCuisine() {
		return "/WEB-INF/jsp/addCuisine.jsp" ; 
	}
	
	//���Ӳ˵�����
	@RequestMapping("/addmenulist.action")
	public String addmenulist(Menu m) {
		System.out.println(new Date());
		m.setAddtime(new Date());
		m.setHeat(0);
		Integer addMenu = service.addMenu(m);
		System.out.println(addMenu);
		service.updateCuisineCount(m.getCuisine());
		return "redirect:/addCuisine.action" ; 
		
	}
	
	//���Ӳ�ϵ����
	@RequestMapping("/opcuisine.action")
	public String opcuisine(HttpServletRequest req) {
		String cname = req.getParameter("cname") ; 
		Cuisine c = new Cuisine() ; 
		c.setCname(cname);
		service.addCuisine(c);
		return "/addCuisine.action" ; 
	}
	
	//ɾ����ϵ����
	@RequestMapping("deletecuisine.action")
	public String deletecuisine(String id) {
//		req.getParameter("cid") ; 
//		service.addCuisine(c);
//		System.out.println(id);
		int cid = Integer.parseInt(id) ; 
		service.deleteCuisineByid(cid);
		service.deleteByCid(cid);
		return "redirect:/cuisine.action" ; 
		
	}
	//��Ա�б���ʾ����
	@RequestMapping("/viplist.action")
	public ModelAndView viplist() {
		ModelAndView mv = new ModelAndView() ; 
		List<Vip> viplist = vservice.findVip() ; 
		mv.addObject("viplist", viplist) ; 
		mv.setViewName("/WEB-INF/jsp/viplist.jsp");
		return mv ; 
	}
	//��ʾ������Ϣ
	@RequestMapping("/tablelist.action")
	public ModelAndView tableList() {
		ModelAndView mv = new ModelAndView()  ; 
		List<Dtable> tablelist = oservice.findAllTable() ;
		System.out.println(tablelist);
		mv.addObject("tablelist",tablelist) ; 
		mv.setViewName("/WEB-INF/jsp/tablelist.jsp");
		return mv; 
	}
	//��������
	@RequestMapping("/openorder.action")
	public ModelAndView openorder() {
		ModelAndView mv = new ModelAndView() ; 
		List<MenuVo> menu = service.findByAllVmenuS();
		mv.addObject("menu",menu) ; 
		mv.addObject("menu1",mlist) ;
		mv.setViewName("/WEB-INF/jsp/openorder.jsp");
		return mv ; 
	}
	//�������ɲ���
	@RequestMapping("/addtemmenu.action")
	public ModelAndView addtemmenu(Integer id) {
		ModelAndView mv = new ModelAndView() ; 
		List<MenuVo> menu = service.findByAllVmenuS() ;
		mv.addObject("menu",menu) ; 
		MenuVo menu1 = service.findByIdMenuVo(id) ;
		System.out.println(menu1);
		mlist.add(menu1) ; 
		System.out.println(mlist);
		mv.addObject("menu1",mlist) ; 
		mv.setViewName("/WEB-INF/jsp/openorder.jsp");
		return mv ; 
	}
	
	//ɾ����������
	@RequestMapping("/deleteorder1.action")
	public String deleteorder1(Integer id) {
		System.out.println(id);
		mlist.remove(mlist.get(id)) ; 
		System.out.println(mlist);
		return "redirect:/openorder.action" ; 
	}
	//ɾ���˵�����
	@RequestMapping("/deletemenu.action")
	public String deletemenu(Integer id) {
//		System.out.println(id);
		Menu menu = service.findByIdMenu(id);
		service.deleteMenuById(id);
		service.subCuisineCount(menu.getCuisine());
		return "redirect:/menulist.action" ; 
	}
	//�����б�
	@RequestMapping("/orderlist.action")
	public ModelAndView orderlist() {
		ModelAndView mv = new ModelAndView() ; 
		List<Ordertable> list = oservice.findOrder() ;
		for(Ordertable o:list) {
			o.setName(vservice.findByVidN(o.getVid()).getVname());
			
		}
		mv.addObject("mlist", list) ;
		mv.setViewName("/WEB-INF/jsp/orderlist.jsp");
		return mv ; 
	}
	
	//ɾ����ʱ��������
	@RequestMapping("/delteTemOrder.action")
	public String delteTemOrder() {
		mlist.clear();
		return "redirect:/openorder.action" ; 
	}
	//���Ӷ�������
	@RequestMapping("/addorder.action")
	public ModelAndView addorder() {
		ModelAndView mv = new ModelAndView() ;
		List<Dtable> list = oservice.findByActionTable() ; 
		mv.addObject("tlist", list) ; 
		mv.setViewName("/WEB-INF/jsp/addOrder.jsp");		
		return mv ; 
	}
	//�����Ա���ӽ���
	@RequestMapping("/addvip.action")
	public String addvip() {
		return "/WEB-INF/jsp/addvip.jsp" ; 
	}
	
	//���ӻ�Ա����
	@RequestMapping("/opaddvip.action")
	public String opaddvip(Vip vip) {
		vip.setOpentime(new Date());
		vip.setUsecount(0);
		System.out.println(vip);
		vservice.addVip(vip);
		return "redirect:/addvip.action" ;
	}
	
	//���Ӳ�������
	@RequestMapping("/addtable.action")
	public String addtable() {
		
		return  "/WEB-INF/jsp/addtable.jsp" ;
	}
	//���Ӳ����������
	@RequestMapping("/opaddtable.action")
	public String opaddtable(Dtable t) {
		oservice.addTable(t);
		return "redirect:/addtable.action" ; 
	}
	//���Ӷ�������Ĳ���
	@RequestMapping("/opaddorder.action")
	public ModelAndView opaddorder(Vip v,HttpServletRequest req) {
		Vip vip = vservice.findByNameAndPhone(v) ; 
		ModelAndView mv = new ModelAndView() ; 
		if(vip == null) {
			mv.setViewName("redirect:/addorder.action");
		}
		else {
			vip.setUsecount(vip.getUsecount()+1);
			vservice.adduseCount(vip);
			Ordertable o = new Ordertable() ;
			double sum  = 0;  
			for(MenuVo m:mlist) {
				sum+=m.getPrice(); 
			}
			String t = req.getParameter("tid") ;
			int tid = Integer.parseInt(t) ; 
			mv.addObject("sum", sum) ; 
			mv.addObject("tid",tid) ; 
			
			Dtable t1 = oservice.findByTid(tid);
			mv.addObject("tposition", t1.getTposition());
			o.setVid(vip.getVid());
			o.setGtime(new Date());
			o.setTotalprice(sum);
			o.setTid(tid);
			oservice.addOrder(o);
			oservice.updateTableState(tid);
			//��ÿһ���ò͵��ȶȼ�1
			for(MenuVo m: mlist) {
				int id = m.getMid() ; 
				Menu menu = service.findByIdMenu(id);
				menu.setHeat(menu.getHeat()+1);
				service.addHeat(menu);
			}
			mlist.clear();
			mv.setViewName("/WEB-INF/jsp/temorder.jsp");
		}
	 return mv;  
	}
	
	//�޸Ĳ˵�����
	@RequestMapping("/updatemenu.action")
	public ModelAndView updatemenu(Integer  id ) {
		
		ModelAndView mv = new ModelAndView() ; 
		mv.addObject("id", id) ; 
		mv.setViewName("/WEB-INF/jsp/updateMenuname.jsp");
		return mv ; 
	}
	//�޸Ĳ˵�����
	@RequestMapping("/updateMenuname.action")
	public String updateMenuname(Menu m) {
		service.updateMenuName(m);
		System.out.println(m);
		return "redirect:/menulist.action" ; 
	}
	//�޸Ĳ˵����¼ܵ�״̬
	@RequestMapping("/updateState.action")
	public String updateState(Menu m) {
		System.out.println(m);
		service.updateState(m);
		return "redirect:/menulist.action" ;
	}
	//������������
	@RequestMapping("/searchOrder.action")
	public ModelAndView searchOrder(HttpServletRequest req,OrdertableVo v) {
		String state = req.getParameter("state")  ;
//		System.out.println(state);
		String btime = req.getParameter("btime1");
		v.setBtime(btime);
		String etime = req.getParameter("etime1") ; 
		v.setEtime(etime);
		System.out.println(v);
		ModelAndView mv = new ModelAndView() ; 
		if(state.contentEquals("0")) {
		List<Ordertable> list = oservice.findOrderAll(v) ;
		for(Ordertable o:list) {
			o.setName(vservice.findByVidN(o.getVid()).getVname());
			
		}
		mv.addObject("mlist", list) ;
		}
		else if(state.equals("1")) {
			v.setPaymentstate(0);
			List<Ordertable> list = oservice.findOrderAll(v) ;
			for(Ordertable o:list) {
				o.setName(vservice.findByVidN(o.getVid()).getVname());
				
			}
			mv.addObject("mlist", list) ;
		}
		else {
			v.setPaymentstate(1);
			List<Ordertable> list = oservice.findOrderAll(v) ;
			for(Ordertable o:list) {
				o.setName(vservice.findByVidN(o.getVid()).getVname());
				
			}
			mv.addObject("mlist", list) ;
		}
		mv.setViewName("/WEB-INF/jsp/orderlist.jsp");
		return mv ; 
	}
	//֧������
	@RequestMapping("payment.action")
	public ModelAndView payment(Integer id) {
		ModelAndView mv = new ModelAndView() ; 
		Ordertable order = oservice.findByOid(id) ; 
		if (order.getPaymentstate() == 1) {
			mv.setViewName("redirect:/orderlist.action");
			return mv ;
		}
		Vip vip = vservice.findByVid(order.getVid()) ; 
		double sum = 0 ; 
		if(vip.getBalance()>=order.getTotalprice()) {
			sum = 0 ; 
		}
		else {
			sum = order.getTotalprice()-vip.getBalance() ; 
		}
		mv.addObject("vip",vip) ;
		mv.addObject("order", order) ;
		mv.addObject("sum",sum) ; 
		mv.setViewName("/WEB-INF/jsp/vipusing.jsp");
		return mv ;
	}
	//ɾ����Ա
	@RequestMapping("/deletevip.action")
	public ModelAndView deletevip(Integer id) {
		ModelAndView mv = new ModelAndView() ; 
		System.out.println(id);
		vservice.deleteVip(id);
		mv.setViewName("redirect:/viplist.action");
		return mv ; 
	}
	
	//ʹ�û�Ա��
	@RequestMapping("/submitOrder.action")
	public String submitOrder(Integer oid,Integer tid,Double sum) {
		Vip vip = new Vip() ; 
		
		vip.setVid(oservice.findByOid(oid).getVid());
		if(sum<=0) {
			vip.setBalance(0);
			vservice.setBalance(vip);
			
		}
		else {
			vip.setBalance(sum);
			vservice.setBalance(vip);
		}
		oservice.updateUsing(tid);
		oservice.updateOrder(oid);
		return "/orderlist.action" ; 
	}
	//��ʹ�û�Ա��
	@RequestMapping("/cancel.action")
	public String cance(Integer oid,Integer tid) {
		oservice.updateUsing(tid);
		oservice.updateOrder(oid);
		return "/orderlist.action" ; 
	}
	//����Ա���г�ֵ
	@RequestMapping("/updatebalance.action")
	public String updatebalan(Integer id) {
		if(id!=null) {
			vservice.setBa(id);
		}
		return "/viplist.action"; 
	}
	//���۶��
	
	  @RequestMapping("/priceChart.action") 
	  public ModelAndView chart() {
	  ModelAndView mv = new ModelAndView() ; 
	  mv.setViewName("/WEB-INF/jsp/businessChart.jsp"); 
	  return mv ; 
	  }
	 
	//ʹ��Json�������ݵķ�װ�����ݵĴ���
	@ResponseBody
	@RequestMapping("/priceChart01.action") 
	public JsonResult<Map<String,String[]>> getInf() {
		JsonResult<Map<String,String[]>> js = new JsonResult();
		try {
			Map<String,String[]> map = new HashMap<String, String[]>() ; 
			//�����洢����
			String timeseven[] = new String[7] ; 
			String price[] = new String[7] ; 
			
			//��ȡ7����վ�
			for (int i= 0 ; i<=6 ;i++) {
				//���Ȼ�ôӵ�ǰ���ڵ�ʱ��
				Date getdate = TimeConvert.getdate(i);
				String time = TimeConvert.convert(getdate) ;
				CharMode mode = oservice.findTotalPriceByOne(time) ;
				if(mode!=null) {
					price[i] = String.valueOf(mode.getStotalprice()); 
					timeseven[i] = time; 
					
				}
				else {
					price[i] = String.valueOf(0) ; 
					timeseven[i] = time ; 
				}
			}
			//������������е��ô���
			
			timeseven = ArraysReserve.reverse(timeseven); 
			price =ArraysReserve.reverse(price) ;
			 
			map.put("timeseven", timeseven) ; 
			map.put("price", price) ; 
			js.setData(map);	
		}catch (Exception e) {
			// TODO: handle exception
		}
		return js; 
	}
	
	//���ڷ�װjson����
	@ResponseBody
	@RequestMapping("/priceChart02.action") 
	public JsonResult<Map<String,String[]>> getInf02() {
		JsonResult<Map<String,String[]>> js = new JsonResult();
		try {
			Map<String,String[]> map = new HashMap<String, String[]>() ; 
			//�����洢����
			String timeseven[] = new String[31] ; 
			String price[] = new String[31] ; 
			
			//��ȡ7����վ�
			for (int i= 0 ; i<=30 ;i++) {
				//���Ȼ�ôӵ�ǰ���ڵ�ʱ��
				Date getdate = TimeConvert.getdate(i);
				String time = TimeConvert.convert(getdate) ;
				CharMode mode = oservice.findTotalPriceByOne(time) ;
				if(mode!=null) {
					price[i] = String.valueOf(mode.getStotalprice()); 
					timeseven[i] = time; 
					
				}
				else {
					price[i] = String.valueOf(0) ; 
					timeseven[i] = time ; 
				}
			}
			//������������е��ô���
			
			timeseven = ArraysReserve.reverse(timeseven); 
			price =ArraysReserve.reverse(price) ;
			 
			map.put("timeseven", timeseven) ; 
			map.put("price", price) ; 
			js.setData(map);	
		}catch (Exception e) {
			// TODO: handle exception
		}
		return js; 
	}
	
	//��ʾ���Ȳ�Ʒ����
	@RequestMapping("/menuChart.action")
	public ModelAndView MenuChart() {
		ModelAndView mv = new ModelAndView() ; 
		mv.setViewName("/WEB-INF/jsp/menuChart.jsp");
		return mv; 
	}
	//���ڷ�װ��Ʒ���ȶ�JSON����
	@ResponseBody
	@RequestMapping("/menuChart01.action")
	public JsonResult<Map<String,String[]>> menu01(){
		JsonResult<Map<String, String[]>> js = new JsonResult<Map<String, String[]>>();
		Map<String,String[]> map = new HashMap<String, String[]>() ; 
		try {
			List<Menu> menu = service.findAllMenu() ;
			int len = menu.size() ; 
			String [] mname = new String[len] ;
			String [] mheat = new String[len] ;
			
			for(int i =0 ; i<len; i++) {
				mname[i] = menu.get(i).getMname() ; 
				mheat[i] = String.valueOf(menu.get(i).getHeat()) ;
			}
			map.put("mname", mname) ; 
			map.put("mheat", mheat);
			js.setData(map);
			
		}catch (Exception e) {
			// TODO: handle exception
		}
		return js;
	}
	
	//��ǰ̨��ʾ����
	@RequestMapping("/command.action")
	public ModelAndView Command() {
		
		ModelAndView mv = new ModelAndView() ;
		double sum1 = 0 ; 
		double sum2 = 0 ; 
		double sum = 0 ; 
		List<CharMode> list2 = oservice.findTotalPrice() ;
		for(CharMode c:list2) {
			sum+=c.getStotalprice() ; 
		}
		sum1 = (sum/100000)*100;
		List<Anyname> list = sservice.findByAllText() ;
		mv.addObject("list",list) ; 
		mv.addObject("size",list.size()) ; 	
		mv.addObject("sum1",sum1) ; 
		System.out.println(TimeConvert.getDay());
		sum2 = ((double)TimeConvert.getDay() / 365 )*100 ;
		System.out.println(sum2);
		mv.addObject("sum2",sum2) ; 
		mv.setViewName("/WEB-INF/jsp/remark.jsp");
		return mv ; 
	}
	
	
	//��������
	@RequestMapping("/suggestion.action")
	public String suggestion(Anyname anyname) {
		anyname.setGtime(new Date());
		System.out.println(anyname);
		sservice.addSuggestion(anyname);
		return "/submitsuggest.html" ;  
	}
	

}
 