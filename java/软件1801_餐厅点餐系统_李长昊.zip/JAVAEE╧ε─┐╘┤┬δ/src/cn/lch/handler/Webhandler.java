package cn.lch.handler;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import cn.lch.beans.Customer;
import cn.lch.beans.Merchant;



public class Webhandler implements HandlerInterceptor {

	@Override
	public void afterCompletion(HttpServletRequest arg0, HttpServletResponse arg1, Object arg2, Exception arg3)
			throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void postHandle(HttpServletRequest arg0, HttpServletResponse arg1, Object arg2, ModelAndView arg3)
			throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean preHandle(HttpServletRequest req, HttpServletResponse res, Object arg2) throws Exception {
		String url = req.getRequestURI() ;
		String path = req.getContextPath() ; 
		String fullPath = path+url ; 
		System.out.println(fullPath);
		if (fullPath.contains("/login.action")  || fullPath.contains("/register.action")|| fullPath.contains("/index.action")|| fullPath.contains("/suggestion.action")) {
			return true; 
		}
		if(fullPath.contains("/addUser.action"))
			return true; 
		HttpSession session = req.getSession() ;
		Merchant muser = (Merchant) session.getAttribute("muser") ; 
		System.out.println(muser);
		if(muser!=null) {
			return true ; 
		}
		req.getRequestDispatcher("login.action").forward(req, res);
		return false;
	}

}
