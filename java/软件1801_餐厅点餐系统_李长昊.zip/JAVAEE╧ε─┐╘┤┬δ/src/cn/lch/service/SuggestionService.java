package cn.lch.service;

import java.util.List;

import cn.lch.beans.Anyname;

public interface SuggestionService {
	
	public void addSuggestion(Anyname anyname) ; 
	public List<Anyname> findByAllText() ; 

}
