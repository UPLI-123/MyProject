package cn.lch.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.lch.beans.Anyname;
import cn.lch.mapper.AnynameMapper;
import cn.lch.service.SuggestionService;

@Service
public class SuggestionServiceImpl implements SuggestionService{
	
	@Autowired
	AnynameMapper adao ; 
	
	//��������
	@Override
	public void addSuggestion(Anyname anyname) {
		adao.addSuggestion(anyname);
	}

	@Override
	public List<Anyname> findByAllText() {
		// TODO Auto-generated method stub
		return adao.findByAllText();
	}
	
}
