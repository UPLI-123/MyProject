package cn.lch.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.lch.beans.Cuisine;
import cn.lch.beans.Customer;
import cn.lch.beans.Dtable;
import cn.lch.beans.Menu;
import cn.lch.beans.MenuVo;
import cn.lch.beans.Merchant;
import cn.lch.beans.Ordertable;
import cn.lch.beans.OrdertableVo;
import cn.lch.beans.Vip;
import cn.lch.mapper.CuisineMapper;
import cn.lch.mapper.CustomerMapper;
import cn.lch.mapper.DtableMapper;
import cn.lch.mapper.MenuMapper;
import cn.lch.mapper.MerchantMapper;
import cn.lch.mapper.OrderTMapper;
import cn.lch.mapper.VipMapper;
import cn.lch.service.WebService;
@Service
public class WebServiceImpl implements WebService {
	
	
	@Autowired
	MerchantMapper mdao  ; 
	@Autowired
	CustomerMapper cdao ; 
	@Autowired
	MenuMapper dao ;
	@Autowired
	CuisineMapper cmdao ;

	@Override
	public Customer findAllC(String username) {
		return cdao.findAllC(username);
	}

	@Override
	public Merchant findAllM(String username) {
		return  mdao.findAllM(username);
	}

	@Override
	public void addMerchant(Merchant muser) {
			mdao.addMerchant(muser);
	}

	@Override
	public void addCustomer(Customer cuser) {
		cdao.addCustomer(cuser);
	}

	@Override
	public List<Menu> findAllMenu() {
		return dao.findAllMenu();
	}

	@Override
	public List<Cuisine> findAllCuisine() {
		return cmdao.findAllCuisine();
	}

	@Override
	public void addCuisine(Cuisine c) {
		cmdao.addCuisine(c); 
	}

	@Override
	public void deleteCuisineByid(Integer id) {
		cmdao.deleteCuisineByid(id);
		
	}


	@Override
	public Menu findByIdMenu(int id) {
		return dao.findByIdMenu(id);
	}

	@Override
	public void deleteMenuById(int id) {
		dao.deleteMenuById(id);
		
	}

	@Override
	public Integer addMenu(Menu m) {
		return dao.addMenu(m);
	}

	@Override
	public void updateCuisineCount(Integer id) {
		cmdao.updateCuisineCount(id);
	}

	@Override
	public void deleteByCid(Integer cuisine) {
		dao.deleteByCid(cuisine);
	}

	@Override
	public List<MenuVo> findByAllVmenu() {
		
		return dao.findByAllVmenu();
	}

	@Override
	public void subCuisineCount(Integer id) {
		cmdao.subCuisineCount(id);
		
	}



	@Override
	public void updateMenuName(Menu m) {
		dao.updateMenuName(m);
	}

	@Override
	public void updateState(Menu m) {
		dao.updateState(m);
	}

	@Override
	public MenuVo findByIdMenuVo(int id) {
		return dao.findByIdMenuVo(id);
	}

	@Override
	public List<MenuVo> findByAllVmenuS() {
		
		return dao.findByAllVmenuS();
	}

	@Override
	public void addHeat(Menu m) {
		dao.addHeat(m);
	}
	




}
