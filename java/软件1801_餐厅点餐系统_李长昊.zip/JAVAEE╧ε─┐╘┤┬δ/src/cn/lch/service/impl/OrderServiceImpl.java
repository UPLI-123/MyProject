package cn.lch.service.impl;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.lch.beans.CharMode;
import cn.lch.beans.Dtable;
import cn.lch.beans.Ordertable;
import cn.lch.beans.OrdertableVo;
import cn.lch.beans.Vip;
import cn.lch.mapper.DtableMapper;
import cn.lch.mapper.OrderTMapper;
import cn.lch.service.OrderService;
@Service
public class OrderServiceImpl implements OrderService {

	@Autowired 
	DtableMapper tdao; 
	@Autowired
	OrderTMapper odao; 
	
	@Override
	public List<Dtable> findAllTable() {
		
		return tdao.findAllTable();
	}

	@Override
	public List<Ordertable> findOrder() {
		// TODO Auto-generated method stub
		return odao.findOrder();
	}


	@Override
	public void addTable(Dtable table) {
		tdao.addTable(table);

	}

	@Override
	public void addOrder(Ordertable o) {
		odao.addOrder(o);

	}

	@Override
	public void updateTableState(Integer id) {
		tdao.updateTableState(id);

	}

	@Override
	public Dtable findByTid(Integer tid) {
		// TODO Auto-generated method stub
		return tdao.findByTid(tid);
	}

	@Override
	public List<Dtable> findByActionTable() {
		// TODO Auto-generated method stub
		return tdao.findByActionTable();
	}

	@Override
	public List<Ordertable> findOrderAll(OrdertableVo v) {
		// TODO Auto-generated method stub
		return odao.findOrderAll(v);
	}

	@Override
	public Ordertable findByOid(int id) {
		// TODO Auto-generated method stub
		return odao.findByOid(id);
	}

	@Override
	public void updateOrder(int id) {
		odao.updateOrder(id);

	}

	@Override
	public void updateUsing(Integer id) {
		tdao.updateUsing(id);

	}

	@Override
	public List<CharMode> findTotalPrice() {
		return odao.findTotalPrice();
	}

	@Override
	public CharMode findTotalPriceByOne(String time) {
		
		return odao.findTotalPriceByOne(time);
	}

}
