package cn.lch.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.lch.beans.Vip;
import cn.lch.mapper.VipMapper;
import cn.lch.service.VipService;
@Service
public class VipImpl implements VipService {
	
	@Autowired
	VipMapper vdao; 
	

	@Override
	public List<Vip> findVip() {
		// TODO Auto-generated method stub
		return vdao.findVip();
	}

	@Override
	public Vip findByNameAndPhone(Vip v) {
		// TODO Auto-generated method stub
		return vdao.findByNameAndPhone(v);
	}

	@Override
	public void deleteVip(Integer id) {
		vdao.deleteVip(id);

	}

	@Override
	public Vip findByVid(Integer id) {
		// TODO Auto-generated method stub
		return vdao.findByVid(id);
	}

	@Override
	public void setBalance(Vip v) {
		vdao.setBalance(v);

	}

	@Override
	public void addVip(Vip vip) {
		vdao.addVip(vip);

	}

	@Override
	public void adduseCount(Vip v) {
		vdao.adduseCount(v);
		
	}

	@Override
	public Vip findByVidN(Integer id) {
		// TODO Auto-generated method stub
		return vdao.findByVidN(id);
	}

	@Override
	public void setBa(Integer id) {
		vdao.setBa(id);
		
	}

}
