package cn.lch.service;

import java.util.List;

import cn.lch.beans.Vip;

public interface VipService {
	
	//��Ա
	public List<Vip> findVip() ; 
	public Vip findByNameAndPhone(Vip v) ;
	public void deleteVip(Integer id)  ; 
	public Vip findByVid(Integer id) ; 
	public void setBalance(Vip v) ;
	public void addVip(Vip vip) ;
	public void adduseCount(Vip v) ;
	public Vip findByVidN(Integer id) ; 
	public void setBa(Integer id) ; 

}
