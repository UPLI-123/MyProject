package cn.lch.service;

import java.util.Date;
import java.util.List;

import cn.lch.beans.CharMode;
import cn.lch.beans.Dtable;
import cn.lch.beans.Ordertable;
import cn.lch.beans.OrdertableVo;
import cn.lch.beans.Vip;

public interface OrderService {
	//���� ����
	public List<Dtable> findAllTable() ; 
	public List<Ordertable> findOrder();
	public void addTable(Dtable table) ; 
	public void addOrder(Ordertable o) ; 
	public void updateTableState(Integer id) ;
	public Dtable findByTid(Integer tid) ; 
	public List<Dtable> findByActionTable() ; 
	public List<Ordertable> findOrderAll(OrdertableVo v); 
	public Ordertable findByOid(int id) ; 
	public void updateOrder(int id)  ;
	public void updateUsing(Integer id );
	//������ʾͼ��
	public List<CharMode> findTotalPrice() ; 
	//�������������в�ѯ
	public CharMode findTotalPriceByOne(String time) ; 

}
