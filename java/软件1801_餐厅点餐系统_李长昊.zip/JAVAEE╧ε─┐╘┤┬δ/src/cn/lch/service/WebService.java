package cn.lch.service;

import java.util.List;

import cn.lch.beans.Cuisine;
import cn.lch.beans.Customer;
import cn.lch.beans.Dtable;
import cn.lch.beans.Menu;
import cn.lch.beans.MenuVo;
import cn.lch.beans.Merchant;
import cn.lch.beans.Ordertable;
import cn.lch.beans.OrdertableVo;
import cn.lch.beans.Vip;

public interface WebService {
	//�û�
	public Customer findAllC(String username);
	public Merchant findAllM(String username);
	public void addMerchant(Merchant muser) ; 
	public void addCustomer(Customer cuser) ; 
	//�˵�����ϵ
	public List<Menu> findAllMenu() ;
	public List<Cuisine> findAllCuisine()  ; 
	public void addCuisine(Cuisine c) ; 
	public void deleteCuisineByid(Integer id) ; 
	public Menu findByIdMenu(int id) ; 
	public void deleteMenuById(int id) ; 
	public Integer addMenu(Menu m) ; 
	public void updateCuisineCount(Integer id) ; 
	public void deleteByCid(Integer cuisine) ; 
	public List<MenuVo> findByAllVmenu();
	public void subCuisineCount(Integer id) ;
	public void updateMenuName(Menu m) ; 
	public void updateState(Menu m) ;
	public MenuVo findByIdMenuVo(int id) ;
	public List<MenuVo> findByAllVmenuS();
	public void addHeat(Menu m)  ; 
	 



}
