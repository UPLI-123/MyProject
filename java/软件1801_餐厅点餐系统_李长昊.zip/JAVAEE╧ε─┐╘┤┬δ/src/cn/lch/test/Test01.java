package cn.lch.test;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import cn.lch.beans.Manger;
import cn.lch.mapper.manger.MangerMapper;

public class Test01 {
	
	@Test
	public void test01() {
		
		ApplicationContext ac  = new ClassPathXmlApplicationContext("applicationContext.xml") ; 
		MangerMapper ma = (MangerMapper)ac.getBean("mangerMapper") ; 
		Manger manger = ma.findPassword("lihua") ;
		System.out.println(manger);
	}

}
