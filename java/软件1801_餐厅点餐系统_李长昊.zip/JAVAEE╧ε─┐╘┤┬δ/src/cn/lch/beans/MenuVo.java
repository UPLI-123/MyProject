package cn.lch.beans;

import java.util.Date;

public class MenuVo {
	
	private Integer mid ; 
	private String mname ; 
	private String cname ; 
	private Double price ; 
	private Integer state ; 
	private Date addtime;
	private Integer heat;
	public MenuVo() {
		super();
		// TODO Auto-generated constructor stub
	}
	public MenuVo(Integer mid, String mname, String cname, Double price, Integer state, Date addtime, Integer heat) {
		super();
		this.mid = mid;
		this.mname = mname;
		this.cname = cname;
		this.price = price;
		this.state = state;
		this.addtime = addtime;
		this.heat = heat;
	}
	@Override
	public String toString() {
		return "MenuVo [mid=" + mid + ", mname=" + mname + ", cname=" + cname + ", price=" + price + ", state=" + state
				+ ", addtime=" + addtime + ", heat=" + heat + "]";
	}
	public Integer getMid() {
		return mid;
	}
	public void setMid(Integer mid) {
		this.mid = mid;
	}
	public String getMname() {
		return mname;
	}
	public void setMname(String mname) {
		this.mname = mname;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	public Integer getState() {
		return state;
	}
	public void setState(Integer state) {
		this.state = state;
	}
	public Date getAddtime() {
		return addtime;
	}
	public void setAddtime(Date addtime) {
		this.addtime = addtime;
	}
	public Integer getHeat() {
		return heat;
	}
	public void setHeat(Integer heat) {
		this.heat = heat;
	}
	
}
