package cn.lch.beans;



public class OrdertableVo {
	
	private Integer oid; 
	private Integer vid ; 
	private Integer tid; 
	private Double totalprice ; 
	private Integer paymentstate; 
	private String gtime;
	private String btime ; 
	private String etime;
	private String vname;
	public OrdertableVo() {
		super();

	}
	public OrdertableVo(Integer oid, Integer vid, Integer tid, Double totalprice, Integer paymentstate, String gtime,
			String btime, String etime, String vname) {
		super();
		this.oid = oid;
		this.vid = vid;
		this.tid = tid;
		this.totalprice = totalprice;
		this.paymentstate = paymentstate;
		this.gtime = gtime;
		this.btime = btime;
		this.etime = etime;
		this.vname = vname;
	}
	@Override
	public String toString() {
		return "OrdertableVo [oid=" + oid + ", vid=" + vid + ", tid=" + tid + ", totalprice=" + totalprice
				+ ", paymentstate=" + paymentstate + ", gtime=" + gtime + ", btime=" + btime + ", etime=" + etime
				+ ", vname=" + vname + "]";
	}
	public Integer getOid() {
		return oid;
	}
	public void setOid(Integer oid) {
		this.oid = oid;
	}
	public Integer getVid() {
		return vid;
	}
	public void setVid(Integer vid) {
		this.vid = vid;
	}
	public Integer getTid() {
		return tid;
	}
	public void setTid(Integer tid) {
		this.tid = tid;
	}
	public Double getTotalprice() {
		return totalprice;
	}
	public void setTotalprice(Double totalprice) {
		this.totalprice = totalprice;
	}
	public Integer getPaymentstate() {
		return paymentstate;
	}
	public void setPaymentstate(Integer paymentstate) {
		this.paymentstate = paymentstate;
	}
	public String getGtime() {
		return gtime;
	}
	public void setGtime(String gtime) {
		this.gtime = gtime;
	}
	public String getBtime() {
		return btime;
	}
	public void setBtime(String btime) {
		this.btime = btime;
	}
	public String getEtime() {
		return etime;
	}
	public void setEtime(String etime) {
		this.etime = etime;
	}
	public String getVname() {
		return vname;
	}
	public void setVname(String vname) {
		this.vname = vname;
	} 
	
	
}
