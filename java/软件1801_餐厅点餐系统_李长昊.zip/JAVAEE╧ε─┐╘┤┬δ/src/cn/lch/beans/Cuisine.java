package cn.lch.beans;

public class Cuisine {
	
	private Integer cid; 
	private String cname ; 
	private Integer count ;
	public Cuisine() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Cuisine(Integer cid, String cname, Integer count) {
		super();
		this.cid = cid;
		this.cname = cname;
		this.count = count;
	}
	@Override
	public String toString() {
		return "Cuisine [cid=" + cid + ", cname=" + cname + ", count=" + count + "]";
	}
	public Integer getCid() {
		return cid;
	}
	public void setCid(Integer cid) {
		this.cid = cid;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public Integer getCount() {
		return count;
	}
	public void setCount(Integer count) {
		this.count = count;
	}
	

}
