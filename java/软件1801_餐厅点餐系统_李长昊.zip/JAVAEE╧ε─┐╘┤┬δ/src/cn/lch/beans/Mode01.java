package cn.lch.beans;

import java.util.Arrays;

public class Mode01 {
	
	private String[] datatime ; 
	private Double[] totalprice;
	public Mode01(String[] datatime, Double[] totalprice) {
		super();
		this.datatime = datatime;
		this.totalprice = totalprice;
	}
	public Mode01() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String[] getDatatime() {
		return datatime;
	}
	public void setDatatime(String[] datatime) {
		this.datatime = datatime;
	}
	public Double[] getTotalprice() {
		return totalprice;
	}
	public void setTotalprice(Double[] totalprice) {
		this.totalprice = totalprice;
	}
	@Override
	public String toString() {
		return "Mode01 [datatime=" + Arrays.toString(datatime) + ", totalprice=" + Arrays.toString(totalprice) + "]";
	} 
}
