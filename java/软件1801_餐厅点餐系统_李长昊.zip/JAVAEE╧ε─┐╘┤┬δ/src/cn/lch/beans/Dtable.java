package cn.lch.beans;

public class Dtable {
	
	private Integer tid; 
	private String tposition ;  
	private Integer tusing;
	public Dtable() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Dtable(Integer tid, String tposition, Integer tusing) {
		super();
		this.tid = tid;
		this.tposition = tposition;
		this.tusing = tusing;
	}
	public Integer getTid() {
		return tid;
	}
	public void setTid(Integer tid) {
		this.tid = tid;
	}
	public String getTposition() {
		return tposition;
	}
	public void setTposition(String tposition) {
		this.tposition = tposition;
	}
	public Integer getTusing() {
		return tusing;
	}
	public void setTusing(Integer tusing) {
		this.tusing = tusing;
	}
	@Override
	public String toString() {
		return "Dtable [tid=" + tid + ", tposition=" + tposition + ", tusing=" + tusing + "]";
	} 
	
	

}
