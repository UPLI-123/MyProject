package cn.lch.beans;

import java.util.Date;

public class CharMode {
	
	private Date gtime ; 
	private Double stotalprice ;
	public CharMode() {
		super();
	}
	public CharMode(Date gtime, Double stotalprice) {
		super();
		this.gtime = gtime;
		this.stotalprice = stotalprice;
	}
	@Override
	public String toString() {
		return "CharMode [gtime=" + gtime + ", stotalprice=" + stotalprice + "]";
	}
	public Date getGtime() {
		return gtime;
	}
	public void setGtime(Date gtime) {
		this.gtime = gtime;
	}
	public Double getStotalprice() {
		return stotalprice;
	}
	public void setStotalprice(Double stotalprice) {
		this.stotalprice = stotalprice;
	} 
	
}
