package cn.lch.beans;

import java.util.Date;

public class Vip {
	
	private Integer vid  ;
	private String vname ; 
	private String vsex ; 
	private String vphone ; 
	private Date opentime ; 
	private Integer usecount ; 
	private double balance ; 
	private Integer version ;
	public Vip() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Vip(Integer vid, String vname, String vsex, String vphone, Date opentime, Integer usecount, double balance,
			Integer version) {
		super();
		this.vid = vid;
		this.vname = vname;
		this.vsex = vsex;
		this.vphone = vphone;
		this.opentime = opentime;
		this.usecount = usecount;
		this.balance = balance;
		this.version = version;
	}
	@Override
	public String toString() {
		return "Vip [vid=" + vid + ", vname=" + vname + ", vsex=" + vsex + ", vphone=" + vphone + ", opentime="
				+ opentime + ", usecount=" + usecount + ", balance=" + balance + ", version=" + version + "]";
	}
	public Integer getVid() {
		return vid;
	}
	public void setVid(Integer vid) {
		this.vid = vid;
	}
	public String getVname() {
		return vname;
	}
	public void setVname(String vname) {
		this.vname = vname;
	}
	public String getVsex() {
		return vsex;
	}
	public void setVsex(String vsex) {
		this.vsex = vsex;
	}
	public String getVphone() {
		return vphone;
	}
	public void setVphone(String vphone) {
		this.vphone = vphone;
	}
	public Date getOpentime() {
		return opentime;
	}
	public void setOpentime(Date opentime) {
		this.opentime = opentime;
	}
	public Integer getUsecount() {
		return usecount;
	}
	public void setUsecount(Integer usecount) {
		this.usecount = usecount;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public Integer getVersion() {
		return version;
	}
	public void setVersion(Integer version) {
		this.version = version;
	} 
	
	
	

}
