package cn.lch.beans;

import java.util.Date;

public class Ordertable {
	
	private Integer oid; 
	private Integer vid ; 
	private Integer tid; 
	private Double totalprice ; 
	private Integer paymentstate; 
	private Date gtime;
	private String name;
	public Ordertable() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Ordertable(Integer oid, Integer vid, Integer tid, Double totalprice, Integer paymentstate, Date gtime,
			String name) {
		super();
		this.oid = oid;
		this.vid = vid;
		this.tid = tid;
		this.totalprice = totalprice;
		this.paymentstate = paymentstate;
		this.gtime = gtime;
		this.name = name;
	}
	@Override
	public String toString() {
		return "Ordertable [oid=" + oid + ", vid=" + vid + ", tid=" + tid + ", totalprice=" + totalprice
				+ ", paymentstate=" + paymentstate + ", gtime=" + gtime + ", name=" + name + "]";
	}
	public Integer getOid() {
		return oid;
	}
	public void setOid(Integer oid) {
		this.oid = oid;
	}
	public Integer getVid() {
		return vid;
	}
	public void setVid(Integer vid) {
		this.vid = vid;
	}
	public Integer getTid() {
		return tid;
	}
	public void setTid(Integer tid) {
		this.tid = tid;
	}
	public Double getTotalprice() {
		return totalprice;
	}
	public void setTotalprice(Double totalprice) {
		this.totalprice = totalprice;
	}
	public Integer getPaymentstate() {
		return paymentstate;
	}
	public void setPaymentstate(Integer paymentstate) {
		this.paymentstate = paymentstate;
	}
	public Date getGtime() {
		return gtime;
	}
	public void setGtime(Date gtime) {
		this.gtime = gtime;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	} 
	
	
	
	

}
