package cn.lch.beans;

import java.util.Date;

public class Menu {
	
	private Integer mid ; 
	private String mname ; 
	private Integer cuisine ; 
	private Double price ; 
	private Integer state ; 
	private Date addtime;
	private Integer heat;
	public Menu() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Menu(Integer mid, String mname, Integer cuisine, Double price, Integer state, Date addtime, Integer heat) {
		super();
		this.mid = mid;
		this.mname = mname;
		this.cuisine = cuisine;
		this.price = price;
		this.state = state;
		this.addtime = addtime;
		this.heat = heat;
	}
	@Override
	public String toString() {
		return "Menu [mid=" + mid + ", mname=" + mname + ", cuisine=" + cuisine + ", price=" + price + ", state="
				+ state + ", addtime=" + addtime + ", heat=" + heat + "]";
	}
	public Integer getMid() {
		return mid;
	}
	public void setMid(Integer mid) {
		this.mid = mid;
	}
	public String getMname() {
		return mname;
	}
	public void setMname(String mname) {
		this.mname = mname;
	}
	public Integer getCuisine() {
		return cuisine;
	}
	public void setCuisine(Integer cuisine) {
		this.cuisine = cuisine;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	public Integer getState() {
		return state;
	}
	public void setState(Integer state) {
		this.state = state;
	}
	public Date getAddtime() {
		return addtime;
	}
	public void setAddtime(Date addtime) {
		this.addtime = addtime;
	}
	public Integer getHeat() {
		return heat;
	}
	public void setHeat(Integer heat) {
		this.heat = heat;
	}  
	
	

}
