package cn.lch.beans;

import java.util.Arrays;
//JsonResult��װ�����ں����ǰ�˴�������	
public class JsonResult<T> {
	
	private String[] datatime ; 
	private String[] totalprice;
	private T Data;
	public JsonResult() {
		super();
		// TODO Auto-generated constructor stub
	}
	public JsonResult(String[] datatime, String[] totalprice, T data) {
		super();
		this.datatime = datatime;
		this.totalprice = totalprice;
		Data = data;
	}
	@Override
	public String toString() {
		return "JsonResult [datatime=" + Arrays.toString(datatime) + ", totalprice=" + Arrays.toString(totalprice)
				+ ", Data=" + Data + "]";
	}
	public String[] getDatatime() {
		return datatime;
	}
	public void setDatatime(String[] datatime) {
		this.datatime = datatime;
	}
	public String[] getTotalprice() {
		return totalprice;
	}
	public void setTotalprice(String[] totalprice) {
		this.totalprice = totalprice;
	}
	public T getData() {
		return Data;
	}
	public void setData(T data) {
		Data = data;
	}
	
}
