package tools;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class TimeConvert {
	
	public static String convert(Date time) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String t = null ; 
		if (time !=null) {
		 try {
			t = sdf.format(time) ;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		}
		return t ;
	}
	
	public static Date getdate(int i) // //��ȡǰ������ iΪ���� ����Ƴ�i�죬����ʱ��ǰ��ǰi��
	 {
		Date dat = null;
		i = -i  ; 
		Calendar cd = Calendar.getInstance();
		cd.add(Calendar.DATE, i);
		dat = cd.getTime();
		SimpleDateFormat dformat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Timestamp date = Timestamp.valueOf(dformat.format(dat));
		return date;
	 }
	
	//��õ�ǰ�죬����Ԫ��������
	public static int getDay() {
		int day = 0 ; 
		//�õ�һ�������ʵ��
		Calendar calendar = Calendar.getInstance() ; 
		calendar.setTime(new Date());
		day = calendar.get(Calendar.DAY_OF_YEAR) ;  
		return day ; 
	}
	

}
