package tools;

import com.sun.xml.internal.bind.v2.runtime.unmarshaller.XsiNilLoader.Array;

public class ArraysReserve {
	//���鵹��
	public static String[] reverse(String [] arrys) {
		int len = arrys.length; 
		int i = 0 ; 
		int j =len -1 ; 
		String t; 
		while(i<j) {
			t  = arrys[i] ; 
			arrys[i] =  arrys[j] ; 
			arrys[j] =t ;	
			i++ ; 
			j-- ;
		}
		return arrys ; 
		
	}
}
