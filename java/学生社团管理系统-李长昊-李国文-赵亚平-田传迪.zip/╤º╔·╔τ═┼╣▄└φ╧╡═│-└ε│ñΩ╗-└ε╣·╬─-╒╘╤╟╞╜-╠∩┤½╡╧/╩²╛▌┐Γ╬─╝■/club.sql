/*
 Navicat Premium Data Transfer

 Source Server         : lch1
 Source Server Type    : MySQL
 Source Server Version : 50730
 Source Host           : localhost:3306
 Source Schema         : club

 Target Server Type    : MySQL
 Target Server Version : 50730
 File Encoding         : 65001

 Date: 10/07/2021 11:06:39
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for act_clu
-- ----------------------------
DROP TABLE IF EXISTS `act_clu`;
CREATE TABLE `act_clu`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cid` int(11) NULL DEFAULT NULL,
  `aid` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 48 CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of act_clu
-- ----------------------------
INSERT INTO `act_clu` VALUES (46, 58, 141);

-- ----------------------------
-- Table structure for activity
-- ----------------------------
DROP TABLE IF EXISTS `activity`;
CREATE TABLE `activity`  (
  `act_content` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `act_brief` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `act_stime` varchar(225) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `act_etime` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `act_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `act_state` int(255) NULL DEFAULT NULL,
  `act_id` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `act_place` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `act_phone` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `act_email` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `act_image` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 143 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of activity
-- ----------------------------
INSERT INTO `activity` VALUES ('11', '11', '2021-07-09', '2021-07-31', '11', 2, '709094147891216', '11', 140, '13792344723', '11@qq.com', '77d78d57eScreenshot_1624800879.png');
INSERT INTO `activity` VALUES ('111', '111', '2021-07-10', '2021-07-24', '11', 2, '710090537905551', '111', 142, '13792344723', '1789412739@qq.com', NULL);

-- ----------------------------
-- Table structure for club
-- ----------------------------
DROP TABLE IF EXISTS `club`;
CREATE TABLE `club`  (
  `clu_id` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `clu_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `clu_type` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `clu_brief` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `clu_aim` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `clu_money` double(255, 0) NULL DEFAULT NULL,
  `clu_gtime` varchar(16) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `image1` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `image2` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `image3` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `limits` int(8) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 60 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of club
-- ----------------------------
INSERT INTO `club` VALUES (NULL, '1111', '2', '1', '11', 0, '2021-07-09', 58, NULL, NULL, NULL, 1);

-- ----------------------------
-- Table structure for finance
-- ----------------------------
DROP TABLE IF EXISTS `finance`;
CREATE TABLE `finance`  (
  `fin_id` int(10) NOT NULL AUTO_INCREMENT,
  `act_id` int(10) NOT NULL,
  `clu_id` int(10) NOT NULL,
  `fin_money` double(12, 0) NOT NULL,
  PRIMARY KEY (`fin_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 49 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of finance
-- ----------------------------
INSERT INTO `finance` VALUES (47, 140, 57, 100);
INSERT INTO `finance` VALUES (48, 142, 57, 100);

-- ----------------------------
-- Table structure for stu_act
-- ----------------------------
DROP TABLE IF EXISTS `stu_act`;
CREATE TABLE `stu_act`  (
  `act_id` int(12) NULL DEFAULT NULL,
  `stu_id` int(4) NULL DEFAULT NULL,
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `limt` int(255) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 96 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of stu_act
-- ----------------------------
INSERT INTO `stu_act` VALUES (141, 51, 94, 1);

-- ----------------------------
-- Table structure for stu_clu
-- ----------------------------
DROP TABLE IF EXISTS `stu_clu`;
CREATE TABLE `stu_clu`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stu_id` int(11) NULL DEFAULT NULL,
  `clu_id` int(11) NULL DEFAULT NULL,
  `limit` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 198 CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of stu_clu
-- ----------------------------
INSERT INTO `stu_clu` VALUES (182, 51, 58, 0);
INSERT INTO `stu_clu` VALUES (184, 35, 58, 1);
INSERT INTO `stu_clu` VALUES (185, 39, 58, 1);
INSERT INTO `stu_clu` VALUES (186, 40, 58, 1);
INSERT INTO `stu_clu` VALUES (187, 41, 58, 1);
INSERT INTO `stu_clu` VALUES (188, 43, 58, 1);
INSERT INTO `stu_clu` VALUES (190, 45, 58, 1);
INSERT INTO `stu_clu` VALUES (191, 48, 58, 1);
INSERT INTO `stu_clu` VALUES (192, 50, 58, 1);

-- ----------------------------
-- Table structure for student
-- ----------------------------
DROP TABLE IF EXISTS `student`;
CREATE TABLE `student`  (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `name` varchar(16) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `stu_sex` int(8) NULL DEFAULT NULL,
  `stu_phone` varchar(11) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `stu_email` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `stu_reputation` int(8) NULL DEFAULT NULL,
  `stu_major` varchar(16) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `stu_id` varchar(12) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `stu_uername` varchar(16) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `stu_password` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `stu_limit` int(255) NULL DEFAULT NULL,
  `stu_department` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `image` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `stu_id`(`stu_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 52 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of student
-- ----------------------------
INSERT INTO `student` VALUES (2, '高级管理员', NULL, NULL, NULL, NULL, NULL, '050201', NULL, 'e10adc3949ba59abbe56e057f20f883e', 1, NULL, NULL);
INSERT INTO `student` VALUES (34, '张志成', 0, '13792344723', '1789412739@qq.com', 100, '软件工程', '18110506018', NULL, 'e10adc3949ba59abbe56e057f20f883e', 0, NULL, '');
INSERT INTO `student` VALUES (35, '赵憨憨', 0, '13792344723', '11@qq.com', 0, '软件工程', '18110506020', NULL, 'e10adc3949ba59abbe56e057f20f883e', 0, NULL, '6535f64e02021-06-22_203139.png');
INSERT INTO `student` VALUES (39, '张志成', 0, '13792344723', '11@qq.com', 0, '软件工程', '18110506015', NULL, 'e10adc3949ba59abbe56e057f20f883e', 0, NULL, '919f1e2e8zc.jpg');
INSERT INTO `student` VALUES (40, 'hao li', 0, '13792344723', '525@qq.com', 100, '软件工程', '18110506025', NULL, 'e10adc3949ba59abbe56e057f20f883e', 0, NULL, '1ba969e1e李长昊370811200009025531.jpg');
INSERT INTO `student` VALUES (41, 'xp成哥', 0, '13792344723', '1789412739@qq.com', 100, '软件工程', '18110506028', NULL, 'e10adc3949ba59abbe56e057f20f883e', 0, NULL, '9745a732azc.jpg');
INSERT INTO `student` VALUES (43, 'xp成哥2', 1, '13792344723', '110@qq.com', 100, '软件工程', '18110506036', NULL, 'e10adc3949ba59abbe56e057f20f883e', 0, NULL, 'f8754e7f2zc.jpg');
INSERT INTO `student` VALUES (44, 'xp成哥3', 0, '13792344723', '1789412739@qq.com', 100, '软件工程', '18110506026', NULL, 'e10adc3949ba59abbe56e057f20f883e', 0, NULL, 'fc05827d5zc.jpg');
INSERT INTO `student` VALUES (45, 'xp3', 0, '13792344723', '11@qq.com', 10, '软件工程', '18110506038', NULL, 'e10adc3949ba59abbe56e057f20f883e', 0, NULL, '939e95c1azc.jpg');
INSERT INTO `student` VALUES (48, 'xp3', 0, '13792344723', '11@qq.com', 10, '软件工程', '18110506039', NULL, 'e10adc3949ba59abbe56e057f20f883e', 0, NULL, '939e95c1azc.jpg');
INSERT INTO `student` VALUES (50, 'xp04', 0, '13792344723', '1789412739@qq.com', 100, '软件工程', '18110506035', NULL, 'e10adc3949ba59abbe56e057f20f883e', 0, NULL, '15bd4c34bzc.jpg');
INSERT INTO `student` VALUES (51, 'ss', 0, '13792344723', '178@qq.com', 100, '软件工程', '18110506100', NULL, 'e10adc3949ba59abbe56e057f20f883e', 0, NULL, '5197c30a2ball.png');

SET FOREIGN_KEY_CHECKS = 1;
